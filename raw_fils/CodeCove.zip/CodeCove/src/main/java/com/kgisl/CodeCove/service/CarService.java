package com.kgisl.CodeCove.service;

import java.util.List;

import com.kgisl.CodeCove.model.*;

/**
 * CarService
 */
public interface CarService {
    public List<Car> getCars();

    
}