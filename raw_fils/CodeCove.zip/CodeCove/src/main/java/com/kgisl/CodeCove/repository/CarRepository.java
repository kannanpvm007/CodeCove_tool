package com.kgisl.CodeCove.repository;

import com.kgisl.CodeCove.model.*;

import org.springframework.data.jpa.repository.JpaRepository;

/**
 * CarRepository
 */
public interface CarRepository extends JpaRepository<Car,Long> {

    
}