insert into car (id,name) values (1,'Honda');
insert into car (id,name) values (2,'Hyndai');
insert into car (id,name) values (3,'Suzuki');
insert into car (id,name) values (4,'Renault');
insert into car (id,name) values (5,'Audi');